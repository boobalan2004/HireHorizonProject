import React from 'react';
import Sidebar from './Sidebar';
import Header from './Header';
import StatsCard from './StatsCard';
import './DashboardContainer.css'; // CSS for the main layout

const DashboardContainer = () => {
  return (
    <div className="dashboard-container">
      <Sidebar />
      <div className="main-content21">
        <Header />
        <div className="dashboard-stats">
          <StatsCard title="Total Job Category" count={5} icon="fas fa-book" color="purple" />
          <StatsCard title="Total Registered Employer" count={3} icon="fas fa-building" color="blue" />
          <StatsCard title="Total Registered Candidates" count={2} icon="fas fa-users" color="cyan" />
          <StatsCard title="Total Listed Jobs" count={7} icon="fas fa-briefcase" color="teal" />
        </div>
      </div>
    </div>
  );
};

export default DashboardContainer;
