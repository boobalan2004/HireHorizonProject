import React from 'react';
import { Link } from 'react-router-dom';
import { Box, Grid, Typography, Button } from '@mui/material';
import tcsLogo from './tcs-logo.png';
import iciciLogo from './icici-logo.png';
import wellsFargoLogo from './wellsfargo-logo.png';
import datamaticsLogo from './datamatics-logo.png';
import amazonLogo from './amazon-logo.png';
import actelentLogo from './actalent-logo.png';
import airtelLogo from './airtel-logo.png';
import capegeminiLogo from './capegemini-logo.png';
import chartLogo from './chart-logo.png';
import fisLogo from './fis-logo.png';
import genpactLogo from './genpact-logo.png';
import jioLogo from './jio-logo.png';
import jpLogo from './jp-logo.png';
import persistentLogo from './persistent-logo.png';
import relainceretailLogo from './relianceretail-logo.png';
import xoriantLogo from './xoriant-logo.png';
import accLogo from './accenture-logo.png';

import './CompanyCat.css';

const companies = [
  { src: tcsLogo, name: 'Tata Consultancy Services', rating: '3.8', reviews: '78K+', description: 'Explore challenging and exciting opportunities at TCS' },
  { src: iciciLogo, name: 'ICICI Bank', rating: '4.0', reviews: '34.5K+', description: 'Leading private sector bank in India.' },
  { src: wellsFargoLogo, name: 'Wells Fargo', rating: '4.0', reviews: '5.5K+', description: 'Start your future now' },
  { src: datamaticsLogo, name: 'Datamatics', rating: '3.5', reviews: '1.8K+', description: 'Global digital solutions & technology company.' },
  { src: amazonLogo, name: 'Amazon', rating: '4.1', reviews: '60K+', description: 'World\'s largest e-commerce company.' },
  { src: actelentLogo, name: 'Actalent', rating: '3.7', reviews: '80K+', description: 'Global Engineering company.' },
  { src: airtelLogo, name: 'Airtel', rating: '4.0', reviews: '58K+', description: 'Largest telecom provider.' },
  { src: capegeminiLogo, name: 'CapeGemini', rating: '4.1', reviews: '108K+', description: 'Global leader in consulting and digital transformation.' },
  { src: jioLogo, name: 'Jio', rating: '4.2', reviews: '50K+', description: 'Shaping the Future with Groundbreaking Technology and Consulting.' },
  { src: relainceretailLogo, name: 'Reliance Retail', rating: '3.9', reviews: '18K+', description: 'The Forefront of Technology and Digital Advancement.' },
  { src: chartLogo, name: 'Standard Chartered', rating: '3.8', reviews: '111K+', description: 'Delivering Next-Generation IT Services and Solutions Worldwide.' },
  { src: xoriantLogo, name: 'Xoriant', rating: '3.9', reviews: '35K+', description: 'Global leader in digital transformation.' },
  { src: fisLogo, name: 'FIS', rating: '3.7', reviews: '78K+', description: 'Empowering Businesses through Innovative Technology and Expertise.' },
  { src: genpactLogo, name: 'Genpact', rating: '4.0', reviews: '90K+', description: 'Redefining the Digital Landscape with Cutting-Edge Solutions.' },
  { src: jpLogo, name: 'JP Morgan', rating: '4.3', reviews: '78K+', description: 'Leading the Charge in Digital Transformation and Solutions.' },
  { src: accLogo, name: 'Accenture', rating: '4.1', reviews: '199K+', description: 'Innovating Tomorrow\'s Technology Today.' },
  { src: persistentLogo, name: 'Persistent', rating: '4.2', reviews: '109K+', description: 'Driving Excellence in Global IT and Consulting Services.' },
];

const CompanyCat = () => {
  return (
    <div className="companyCat-container">
      <Box sx={{ textAlign: 'center', marginTop: '20px' }}>
        <Typography variant="h4">HireHorizon Top Companies</Typography>
        <Grid container spacing={4} sx={{ marginTop: '20px', justifyContent: 'center' }}>
          {companies.map((company, index) => (
            <Grid item key={index} xs={12} sm={6} md={4} lg={3} className="companyCat-card">
              <img src={company.src} alt={company.name} className="companyCat-logo" />
              <Typography variant="h6">{company.name}</Typography>
              <Typography variant="body2" className="companyCat-rating">
                {company.rating} <span className="companyCat-reviews">{company.reviews} reviews</span>
              </Typography>
              <Typography variant="body2">{company.description}</Typography>
              <Button variant="contained" color="primary" className="companyCat-viewJobs">
                KNOW MORE
                {/* <Link to="/view1">Know more</Link> */}
              </Button>
            </Grid>
          ))}
        </Grid>
      </Box>
    </div>
  );
};

export default CompanyCat;
